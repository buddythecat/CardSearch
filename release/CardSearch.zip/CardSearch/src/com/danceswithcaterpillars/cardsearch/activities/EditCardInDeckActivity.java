package com.danceswithcaterpillars.cardsearch.activities;

import java.lang.ref.WeakReference;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import static com.danceswithcaterpillars.cardsearch.content.local.db.CardDatabaseConstants.*;

import com.danceswithcaterpillars.cardsearch.R;
import com.danceswithcaterpillars.cardsearch.content.image.GetSetImgTask;
import com.danceswithcaterpillars.cardsearch.content.local.CardDatabaseProvider;
import com.danceswithcaterpillars.cardsearch.model.Card;

import android.app.Activity;
import android.content.ContentValues;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.GestureDetector.SimpleOnGestureListener;
import android.view.View.OnTouchListener;
import android.view.animation.AccelerateInterpolator;
import android.view.animation.Animation;
import android.view.animation.TranslateAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;
import android.widget.TextView;
import android.widget.ViewFlipper;

public class EditCardInDeckActivity extends Activity{
	private static final String TAG = "EditCardInDeckActivity";
	
	public static final int RESULT_DONE = 10;
	public static final int RESULT_DELETE = 11;
	public static final int RESULT_UPDATE = 12;
	
	private Card focusedCard;
	private ViewFlipper fwipper;
	private GestureDetector gestureDetector;
	private OnTouchListener gestureListener;
	private TextView cardName, cardType, cardRule, cardPow, countSliderLabel;
	private LinearLayout manaLayout;
	private ImageView cardImage, setImage;
	private ProgressBar cardImageProgress;
	private SeekBar countSlider;
	
	class EditCardSwipeGesture extends SimpleOnGestureListener {
		//all constants measured in dip
		private static final int SWIPE_MIN_DISTANCE = 100;
		private static final int SWIPE_MAX_OFF_PATH = 550;
		//dip/sec
		private static final int SWIPE_THRESHOLD_VELOCITY = 100;
		
		public boolean onFling(MotionEvent evnt1, MotionEvent evnt2, float velocityY, float velocityX){
			Log.i(TAG, "Fwining!");
			//check to make sure that the swipe doesn't toggle the maximum deviation case (going diagonal)
			if(Math.abs(evnt1.getY()-evnt2.getY()) > SWIPE_MAX_OFF_PATH)
				return false;
			//If the X from event 1 is greater then the X from event 2, the finger moved left, and we're fwipping backwards.
			if((evnt1.getX() - evnt2.getX()) > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY){
				fwipper.setInAnimation(inFromRightAnimation());
				fwipper.setOutAnimation(outToLeftAnimation());
				fwipper.showNext();
			}
			//if the X from event 2 is greater then the X from event 1, the finger moved to the right, and we're fwipping forwards.
			else if((evnt2.getX() - evnt1.getX()) > SWIPE_MIN_DISTANCE && Math.abs(velocityX) > SWIPE_THRESHOLD_VELOCITY){
				fwipper.setInAnimation(inFromLeftAnimation());
				fwipper.setOutAnimation(outToRightAnimation());
				fwipper.showPrevious();
			}
			return super.onFling(evnt1, evnt2, velocityX, velocityY);
		}
	}
	
	private Animation inFromRightAnimation(){
		Animation inFromRight = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, +1.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f);
		inFromRight.setDuration(200);
		inFromRight.setInterpolator(new AccelerateInterpolator());
		return inFromRight;
	}
	
	private Animation outToLeftAnimation(){
		Animation outFromLeft = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, -1.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f);
		outFromLeft.setDuration(200);
		outFromLeft.setInterpolator(new AccelerateInterpolator());
		return outFromLeft;
	}
	
	private Animation inFromLeftAnimation(){
		Animation inFromLeft = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, -1.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f);
		inFromLeft.setDuration(200);
		inFromLeft.setInterpolator(new AccelerateInterpolator());
		return inFromLeft;
	}
	
	private Animation outToRightAnimation(){
		Animation outToRight = new TranslateAnimation(Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, +1.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f, 
				Animation.RELATIVE_TO_PARENT, 0.0f);
		outToRight.setDuration(200);
		outToRight.setInterpolator(new AccelerateInterpolator());
		return outToRight;
	}
	
	@Override
	public void onCreate(Bundle savedInstanceState){
		super.onCreate(savedInstanceState);
		this.setContentView(R.layout.edit_card_from_deck);
		focusedCard = this.getIntent().getExtras().getParcelable("Card");
		fwipper = (ViewFlipper)this.findViewById(R.id.edit_card_flipper);
		gestureDetector = new GestureDetector(this, new EditCardSwipeGesture());
		setGestureListener(new View.OnTouchListener() {
			
			@Override
			public boolean onTouch(View v, MotionEvent event) {
				if(gestureDetector.onTouchEvent(event)){
					return true;
				}
				else
					return false;
			}
		});
		this.initViews();
		
		this.fillDetails();
	}
	
	/**
	 * Initialize all of the views associated with the card detail viewer/editor
	 */
	private void initViews(){
		cardName = (TextView)this.findViewById(R.id.edit_card_details_cardname);
		cardType = (TextView)this.findViewById(R.id.edit_card_details_cardType);
		cardRule = (TextView)this.findViewById(R.id.edit_card_details_rule);
		cardPow = (TextView)this.findViewById(R.id.edit_card_details_powTough);
		
		manaLayout = (LinearLayout)this.findViewById(R.id.edit_card_details_cost);
		
		cardImage = (ImageView)this.findViewById(R.id.edit_card_details_cardimg);
		
		setImage = (ImageView)this.findViewById(R.id.edit_card_details_setImg);
		cardImageProgress = (ProgressBar)this.findViewById(R.id.edit_card_details_imgprogress);
		
		countSliderLabel = (TextView)this.findViewById(R.id.edit_card_details_qtyLabel);
		countSliderLabel.setText("Quantity: "+focusedCard.getQuantity());
		countSlider = (SeekBar)this.findViewById(R.id.edit_card_details_qty);
		countSlider.setMax(4);
		countSlider.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				//focusedCard.setQuantity(seekBar.getProgress());
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				StringBuilder builder = new StringBuilder("Quantity: ");
				builder.append(progress);
				countSliderLabel.setText(builder);
				
			}
		});
	}
	
	private void fillDetails(){
		cardName.setText((CharSequence)focusedCard.getName());
		
		
		String manaCost = focusedCard.getCost();
		manaLayout.removeAllViews();
		Card.buildManaBar(new WeakReference<LinearLayout>(manaLayout), manaCost);
		
		String pow = focusedCard.getPower();
		//case for a creature
		if(!pow.equals("")){
			cardPow.setVisibility(View.VISIBLE);
			pow += "/"+focusedCard.getToughness();
			cardPow.setText(pow);
		}
		//Case for a planeswalker
		else if(!focusedCard.getLoyalty().equals("")){
			cardPow.setVisibility(View.VISIBLE);
			pow = "Loyalty: ";
			pow += focusedCard.getLoyalty();
			cardPow.setText(pow);
		}
		//case for an instant or sorcery
		else{
			cardPow.setVisibility(View.GONE);
		}
		
		String rule = focusedCard.getRule();
		if(rule.length()==0 || rule==null){
			cardRule.setVisibility(View.GONE);
		}
		else{
			cardRule.setVisibility(View.VISIBLE);
			cardRule.setText(Card.buildCardRulesWithImages(rule, getApplicationContext()));	
		}
		
		
		cardType.setText((CharSequence)focusedCard.getFullType());
		
		Log.i(TAG, "Qty of card: "+focusedCard.getQuantity());
		countSlider.setProgress(focusedCard.getQuantity());
		
		JSONArray setInfo = focusedCard.getSetInfo();
		
		if(setInfo.length()>0){
			try{
				JSONObject firstSet = setInfo.getJSONObject(0);
				//String setCode = firstSet.getString("setcode");
				String[][] setInfos = new String[setInfo.length()][3];
				for(int i = 0; i<setInfo.length(); i++){
					firstSet = setInfo.getJSONObject(i);
					setInfos[i][0] = firstSet.getString("setcode");
					setInfos[i][1] = firstSet.getString("rarity");
					setInfos[i][2] = firstSet.getString("number");
				}
				GetSetImgTask retriever = new GetSetImgTask(setImage, null, setInfos);
				retriever.execute(new String[]{
						GetSetImgTask.SET_IMG});
				//setcode.setText(firstSet.getString("setcode"));
				
				retriever = new GetSetImgTask(cardImage, cardImageProgress, setInfos);
				retriever.execute(new String[]{
						GetSetImgTask.CARD_IMG});
			}catch(JSONException e){
				Log.e(TAG, "Error parsing set info", e);
			}
		}
	}
	
	public void finishEditing(View v){
		if(focusedCard.getQuantity() != countSlider.getProgress()){
			//update the card, qty has changed
			if(countSlider.getProgress()==0){
				//remove the card, qty is down to zero
				getContentResolver().delete(CardDatabaseProvider.CONTENT_URI,_ID+"=?",new String[]{String.valueOf(focusedCard.getId())});
			}
			else{
				//simply update the quantity
				focusedCard.setQuantity(countSlider.getProgress());
				ContentValues values = new ContentValues();
				values.put(QUANTITY, focusedCard.getQuantity());
				int updated = getContentResolver().update(CardDatabaseProvider.CONTENT_URI,values,_ID+"=?",new String[]{String.valueOf(focusedCard.getId())});
				if(updated == 0){
					 Log.d(TAG, "Failure! Did not insert card to database");
				 }
				else
					Log.d(TAG, "Updated a total of "+updated+" rows");
			}
			
		}
		this.setResult(RESULT_OK);
		this.finish();
	}
	
    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (gestureDetector.onTouchEvent(event))
	        return true;
	    else
	    	return false;
    }

	public OnTouchListener getGestureListener() {
		return gestureListener;
	}

	public void setGestureListener(OnTouchListener gestureListener) {
		this.gestureListener = gestureListener;
	}
}
