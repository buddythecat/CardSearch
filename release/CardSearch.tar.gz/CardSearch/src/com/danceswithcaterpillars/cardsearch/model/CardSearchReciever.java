package com.danceswithcaterpillars.cardsearch.model;

import java.util.LinkedList;

public interface CardSearchReciever {
	public void buildCardList(LinkedList<Card> cards);
}
